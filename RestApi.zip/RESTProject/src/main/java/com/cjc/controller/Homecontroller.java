package com.cjc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.model.Clock;
import com.cjc.service.ClockService;

@RestController
@RequestMapping("/webapi")
public class Homecontroller {
     @RequestMapping("/test")
	public String test()
	{
		return "It is working";
	}
  @Autowired
  private ClockService service;
  @PostMapping("/insert")
  public void insertdata(@RequestBody Clock clock)
 {
	
    service.saveClock(clock);
	}
}
