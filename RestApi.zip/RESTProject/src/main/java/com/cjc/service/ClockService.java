package com.cjc.service;

import com.cjc.model.Clock;

public interface ClockService {

	void saveClock(Clock clock);

}
