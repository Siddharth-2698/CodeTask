package com.cjc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.dao.ClockDao;
import com.cjc.model.Clock;
@Service
public class ClockServiceImpl implements ClockService {
	@Autowired
	private ClockDao dao;

	@Override
	public void saveClock(Clock clock) {
		String[] s= {"zero","one","two","three","four","five","six","seven",
				   "eight","nine","ten","eleven","twelve","thirteen","fourteen",
				   "fifteen","sixteen","seventeen","eighteen","nineteen","twenty",
				   "twentyone","twentytwo","twentythree","twentyfour"
				};
		int hour=0;
		int minute=0;
		
		if(hour>=12 && hour<=17)
		{
			System.out.println("It is MidDay");
		}
		
		
		else if(hour>=1 && hour<=3)
		{
			System.out.println("It is MidNight");
		}
		
		
		else if(minute==0)
		{
			System.out.println(s[hour]+" o' clock ");
			dao.save(clock);
		}
		
		
		else if(minute==43)
		{
			
			System.out.println(s[hour]+" fourty three minutes");
			dao.save(clock);
		}
	}

}
