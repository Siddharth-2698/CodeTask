package com.cjc.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Clock {
@Id
private String hour;
private String minute;
public String getHour() {
	return hour;
}
public void setHour(String hour) {
	this.hour = hour;
}
public String getMinute() {
	return minute;
}
public void setMinute(String minute) {
	this.minute = minute;
}

}
